package com.example.bop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
