import 'dart:async';

import 'package:bop/bottom_bar.dart';
import 'package:bop/screens/dashboard.dart';
import 'package:flutter/material.dart';

class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(Duration(seconds: 1),(){
      Navigator.pushReplacement(context,MaterialPageRoute(builder: (context) =>bottomBar()),);

    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(

        child:Image.asset('assets/nbp.png')
      ),






    );
  }
}
