import 'package:bop/screens/dashboard.dart';
import 'package:flutter/material.dart';

class bottomBar extends StatefulWidget {
  const bottomBar({super.key});

  @override
  State<bottomBar> createState() => _bottomBarState();
}

class _bottomBarState extends State<bottomBar> {
  int _selectedIndex = 0;
  List<Widget> list = [
    Text("1"),
    Text("2"),
    Text("3"),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,

      home: Scaffold(
          body: Material(
            child: Container(
              height: 1200,
              width: 400,
              child: Padding(
                padding: const EdgeInsets.all(28.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [

                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        Padding(
                          padding: const EdgeInsets.only(top: 0),
                          child: Image(
                            image: NetworkImage(
                              "assets/nbp.png",
                            ),
                            width: 100,
                            height: 40,
                          ),
                        ),
                        Text(
                          "National Bank of  Pakistan",
                          textAlign: TextAlign.start,
                        ),
                      ],
                    ),
                    Text(
                      "   نیشنل بینک آف پاکستان",
                      textAlign: TextAlign.center,
                      style: TextStyle(),
                    ),
                    Card(
                      elevation: 33,
                      child: Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: TextField(
                          keyboardType: TextInputType.text,
                          decoration: InputDecoration(
                            hintText: "UserId/ Mobile Number",
                            label: Text("User Id"),
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ),
                    Card(
                      elevation: 5,
                      child: Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: TextField(
                          keyboardType: TextInputType.text,
                          decoration: InputDecoration(
                            hintText: "Passwrod/ Login Pin",
                            label: Text("Password"),
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text("Forgot Password/Pin?"),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(context,MaterialPageRoute(builder: (context) =>dashboard()),);
                          }, child: Text("Sign In")),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "Do not have an account?",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Register Here?",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 88.0),
                          child: Text(
                            "Term and Condition?",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),

                      ],
                    ),
                    list[_selectedIndex]
                  ],
                ),
              ),
            ),
          ),
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: (index) {
              setState(() {
                _selectedIndex = index;

              });
            },
            items: [
              BottomNavigationBarItem(label: 'Home', icon: Icon(Icons.home)),
              BottomNavigationBarItem(label: 'Serch', icon: Icon(Icons.search)),
              BottomNavigationBarItem(label: 'Call', icon: Icon(Icons.call)),

            ],
            
          ),
        ),

    );
  }
}
